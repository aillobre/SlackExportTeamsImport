import tempfile
import os

SLACKVIEWER_TEMP_PATH = os.path.join(tempfile.gettempdir(), "_slackviewer")
