#!/usr/bin/env python

from slackviewer.main import main

if __name__ == '__main__':
    main()
