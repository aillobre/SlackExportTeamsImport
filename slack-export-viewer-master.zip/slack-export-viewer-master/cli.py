#!/usr/bin/env python

from slackviewer.cli import cli

if __name__ == '__main__':
    cli()
